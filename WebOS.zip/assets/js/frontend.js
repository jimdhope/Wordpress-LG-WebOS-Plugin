(function(){
    // --- Constants and State ---
    var KEY = { LEFT:37, UP:38, RIGHT:39, DOWN:40, ENTER:13, RED:49, GREEN:50, YELLOW:51, BLUE:52 };
    var FOCUSED_CLASS = 'lg-webos-focused';
    var actionBlocks = []; // Holds configured remote-actions blocks
    var menus = []; // Holds configured lgwebos menus
    var activeMenuIndex = -1; // Which menu is currently active for navigation

    /**
     * Initializes all LG webOS blocks on the page once the DOM is ready.
     */
    function initBlocks() {
        // --- Initialize Remote Actions Blocks ---
        document.querySelectorAll('.lgwebos-remote-actions[data-lgwebos]').forEach(function(el) {
            try {
                var config = JSON.parse(el.getAttribute('data-lgwebos') || '{}');
                var panels = document.querySelectorAll('.lgwebos-panel');

                if (panels.length === 0) return;

                var currentIndex = parseInt(config.startIndex, 10) || 0;
                if (currentIndex < 0 || currentIndex >= panels.length) {
                    currentIndex = 0;
                }

                actionBlocks.push({
                    el: el,
                    panels: panels,
                    currentIndex: currentIndex,
                    listenKeys: (config.listenKeys || '').split(',').map(function(k) { return k.trim(); })
                });

                // Set initial focus class on the starting panel
                if (panels[currentIndex]) {
                    panels[currentIndex].classList.add(FOCUSED_CLASS);
                }

            } catch (e) {
                console.error('LG webOS: Error initializing remote-actions block.', e);
            }
        });
        
        // --- Initialize Menus ---
        document.querySelectorAll('nav.lgwebos-menu[data-lgwebos-menu]').forEach(function(menuEl, idx){
            try {
                var cfg = JSON.parse(menuEl.getAttribute('data-lgwebos-menu') || '{}');
                var wrap = !!cfg.wrap;
                var items = menuEl.querySelectorAll('a, button, [data-tv-item]');
                if (items.length === 0) return;

                menus.push({
                    el: menuEl,
                    items: items,
                    wrap: wrap,
                    currentIndex: 0
                });

                // Set initial focus only if menu is visible
                if (!menuEl.classList.contains('hidden')) {
                    items[0].setAttribute('data-tv-focus', 'true');
                    items[0].classList.add(FOCUSED_CLASS);
                    activeMenuIndex = (activeMenuIndex === -1) ? 0 : activeMenuIndex;
                }
            } catch(err) {
                console.error('LG webOS: Error initializing menu', err);
            }
        });
    }

    // --- Minimal LUNA helper ---
    if (!window.LG_WEBOS) window.LG_WEBOS = {};
    window.LG_WEBOS.luna = function(params){
        // If running on webOS TV with webOS.js, prefer native service.request
        if (typeof window.webOS !== 'undefined' && webOS.service && typeof webOS.service.request === 'function') {
            try {
                return new Promise(function(resolve, reject){
                    var req = webOS.service.request(params.service, {
                        method: params.method || 'get',
                        parameters: params.payload || {},
                        onSuccess: function(res){ resolve(res); },
                        onFailure: function(err){ reject(err); }
                    });
                });
            } catch(e){ /* fall through to proxy */ }
        }
        // Fallback to WP REST proxy
        return fetch((LG_WEBOS_WP && LG_WEBOS_WP.rest && LG_WEBOS_WP.rest.root ? LG_WEBOS_WP.rest.root : '') + '/luna', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': LG_WEBOS_WP && LG_WEBOS_WP.rest ? LG_WEBOS_WP.rest.nonce : ''
            },
            body: JSON.stringify(params || {})
        }).then(function(r){ return r.json(); });
    };

    /**
     * Handles `lgwebos:color` events, triggered by the keydown shim or webOS environment.
     */
    document.addEventListener('lgwebos:color', function(e){
        var color = e.detail.color;

        // --- Handle Menus ---
        document.querySelectorAll('[data-lgwebos-menu]').forEach(function(menu){
            try {
                var cfg = JSON.parse(menu.getAttribute('data-lgwebos-menu')||'{}');
                if(cfg.colorKey===color){
                    // Toggle hidden/open for menus
                    var nowHidden = menu.classList.toggle('hidden');
                    if (!nowHidden) {
                        // Ensure newly shown menu has focus
                        for (var mi = 0; mi < menus.length; mi++) {
                            if (menus[mi].el === menu) {
                                var m = menus[mi];
                                var idx = m.currentIndex || 0;
                                if (m.items[idx]) {
                                    m.items[idx].classList.add(FOCUSED_CLASS);
                                    m.items[idx].setAttribute('data-tv-focus', 'true');
                                }
                                activeMenuIndex = mi;
                                break;
                            }
                        }
                    }
                }
            } catch(err){}
        });

        // --- Handle Remote Toggle Blocks (data-lgwebos-toggle) ---
        document.querySelectorAll('[data-lgwebos-toggle]').forEach(function(el){
            try {
                var cfg = JSON.parse(el.getAttribute('data-lgwebos-toggle') || '{}');
                if (cfg.colorKey === color) {
                    el.classList.toggle('hidden');
                }
            } catch(err) {}
        });

        // --- Handle Toggles ---
        document.querySelectorAll('.lgwebos-panel[data-color-key]').forEach(function(panel){
            if(panel.dataset.colorKey === color){
                panel.classList.toggle('hidden');
            }
        });

        // --- Handle Remote Actions ---
        for (var i = 0; i < actionBlocks.length; i++) {
            var block = actionBlocks[i];
            if (block.listenKeys.indexOf('color') !== -1) {
                var panelIndex = -1;
                for (var j = 0; j < block.panels.length; j++) {
                    if (block.panels[j].dataset.colorKey === color) {
                        panelIndex = j;
                        break;
                    }
                }

                if (panelIndex !== -1) {
                    if (block.panels[block.currentIndex]) {
                        block.panels[block.currentIndex].classList.remove(FOCUSED_CLASS);
                    }
                    block.currentIndex = panelIndex;
                    if (block.panels[block.currentIndex]) {
                        block.panels[block.currentIndex].classList.add(FOCUSED_CLASS);
                        block.panels[block.currentIndex].scrollIntoView({ behavior: 'smooth' });
                    }
                }
            }
        }
    });

    /**
     * Global keydown handler for remote control simulation and navigation.
     */
    document.addEventListener('keydown', function(e){
        // 1. Shim for color keys (1, 2, 3, 4) and LG TV color codes (403–406)
        var keyColorMap = { 49: 'red', 50: 'green', 51: 'yellow', 52: 'blue', 403: 'red', 404: 'green', 405: 'yellow', 406: 'blue' };
        var color = keyColorMap[e.keyCode];
        if (color) {
            document.dispatchEvent(new CustomEvent('lgwebos:color', { detail: { color: color } }));
            e.preventDefault();
            return; // It's a color key, so we're done.
        }

        // 2. D-pad navigation for lgwebos menus
        var menuHandled = false;
        if (menus.length > 0) {
            // Find a visible active menu
            var mIdx = -1;
            if (activeMenuIndex >= 0 && !menus[activeMenuIndex].el.classList.contains('hidden')) {
                mIdx = activeMenuIndex;
            } else {
                for (var smi = 0; smi < menus.length; smi++) {
                    if (!menus[smi].el.classList.contains('hidden')) { mIdx = smi; break; }
                }
            }
            if (mIdx !== -1) {
                var menu = menus[mIdx];
                var isPrev = (e.keyCode === KEY.LEFT || e.keyCode === KEY.UP);
                var isNext = (e.keyCode === KEY.RIGHT || e.keyCode === KEY.DOWN);
                if (isPrev || isNext) {
                    var oldIdx = menu.currentIndex;
                    var newIdx = oldIdx + (isNext ? 1 : -1);
                    if (newIdx < 0) newIdx = menu.wrap ? menu.items.length - 1 : 0;
                    if (newIdx >= menu.items.length) newIdx = menu.wrap ? 0 : menu.items.length - 1;
                    if (menu.items[oldIdx]) {
                        menu.items[oldIdx].classList.remove(FOCUSED_CLASS);
                        menu.items[oldIdx].removeAttribute('data-tv-focus');
                    }
                    menu.currentIndex = newIdx;
                    if (menu.items[newIdx]) {
                        menu.items[newIdx].classList.add(FOCUSED_CLASS);
                        menu.items[newIdx].setAttribute('data-tv-focus', 'true');
                        menu.items[newIdx].scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
                    }
                    activeMenuIndex = mIdx;
                    menuHandled = true;
                }
                if (!menuHandled && e.keyCode === KEY.ENTER) {
                    var el = menu.items[menu.currentIndex];
                    if (el) {
                        try { el.classList.add('lgwebos-pressed'); setTimeout(function(){ el.classList.remove('lgwebos-pressed'); }, 150); } catch(_){}
                        var service = el.getAttribute('data-luna-service');
                        if (service) {
                            var method = el.getAttribute('data-luna-method') || 'get';
                            var payloadStr = el.getAttribute('data-luna-payload') || '{}';
                            var payload = {};
                            try { payload = JSON.parse(payloadStr); } catch(_) {}
                            window.LG_WEBOS.luna({ service: service, method: method, payload: payload });
                            menuHandled = true;
                        } else {
                            var href = el.getAttribute('href') || el.getAttribute('data-href');
                            if (!href) {
                                var link = el.querySelector('a[href]');
                                if (link) href = link.getAttribute('href');
                            }
                            var dataTarget = el.getAttribute('data-target');
                            if (dataTarget || (href && href.charAt(0) === '#')) {
                                if (scrollToSectionByRef(dataTarget || href)) { menuHandled = true; }
                            }
                            if (!menuHandled) {
                                if (typeof el.click === 'function') { el.click(); menuHandled = true; }
                                else if (href) { window.location.href = href; menuHandled = true; }
                            }
                        }
                    }
                }
            }
        }

        if (menuHandled) { e.preventDefault(); e.stopPropagation(); return; }

        // 3. Navigation and actions for `remote-actions` blocks
        var handled = false;
        for (var i = 0; i < actionBlocks.length; i++) {
            var block = actionBlocks[i];
            var newIndex = block.currentIndex;

            // Handle Arrow Keys
            if (block.listenKeys.indexOf('arrows') !== -1 && (e.keyCode >= 37 && e.keyCode <= 40)) {
                if (block.panels[block.currentIndex]) {
                    block.panels[block.currentIndex].classList.remove(FOCUSED_CLASS);
                }
                if (e.keyCode === KEY.LEFT || e.keyCode === KEY.UP) newIndex--;
                if (e.keyCode === KEY.RIGHT || e.keyCode === KEY.DOWN) newIndex++;

                // Wrap index
                if (newIndex < 0) newIndex = block.panels.length - 1;
                else if (newIndex >= block.panels.length) newIndex = 0;
                block.currentIndex = newIndex;

                if (block.panels[block.currentIndex]) {
                    block.panels[block.currentIndex].classList.add(FOCUSED_CLASS);
                    block.panels[block.currentIndex].scrollIntoView({ behavior: 'smooth' });
                }
                handled = true;
            }

            // Handle Enter Key
            if (block.listenKeys.indexOf('enter') !== -1 && e.keyCode === KEY.ENTER) {
                if (block.panels[block.currentIndex]) {
                    block.panels[block.currentIndex].click();
                }
                handled = true;
            }

            if (handled) break; // Stop after the first block handles the event
        }

        if (handled) e.preventDefault();
    });

    // Helper to extract hash/id from href or ref
    function extractHash(ref) {
        if (!ref || typeof ref !== 'string') return '';
        // If full URL, use URL API to get hash
        var hash = '';
        try {
            if (ref.indexOf('#') !== -1) {
                var u = new URL(ref, window.location.href);
                hash = u.hash || '';
            }
        } catch(_) {
            // Fallback: take substring after first '#'
            var idx = ref.indexOf('#');
            hash = idx >= 0 ? ref.slice(idx) : '';
        }
        return hash || (ref.charAt(0) === '#' ? ref : ('#' + ref));
    }

    // Helper to scroll to a target element and update focused panel if applicable
    function scrollToSectionByRef(ref) {
        if (!ref) return false;
        var target = null;
        if (typeof ref === 'string') {
            var hash = extractHash(ref);
            var id = hash ? hash.slice(1) : ref;
            target = document.getElementById(id) || document.querySelector(hash || ('#' + id));
        } else if (ref && ref.nodeType === 1) {
            target = ref;
        }
        if (!target) return false;
        if (target.classList && target.classList.contains('lgwebos-panel')) {
            for (var ab = 0; ab < actionBlocks.length; ab++) {
                var blk = actionBlocks[ab];
                if (blk.panels && blk.panels.length) {
                    for (var pi = 0; pi < blk.panels.length; pi++) {
                        if (blk.panels[pi] === target) {
                            if (blk.panels[blk.currentIndex]) blk.panels[blk.currentIndex].classList.remove(FOCUSED_CLASS);
                            blk.currentIndex = pi;
                            blk.panels[blk.currentIndex].classList.add(FOCUSED_CLASS);
                            break;
                        }
                    }
                }
            }
        }
        try { history.replaceState(null, '', '#' + (target.id || '')); } catch(_) {}
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return true;
    }

    // Delegated click/tap: make menu items with hash or data-target scroll
    document.addEventListener('click', function(ev){
        var menuRoot = ev.target.closest && ev.target.closest('nav.lgwebos-menu[data-lgwebos-menu]');
        if (!menuRoot) return;
        var item = ev.target.closest('a, button, [data-tv-item]');
        if (!item) return;
        var href = item.getAttribute('href') || item.getAttribute('data-href');
        var dataTarget = item.getAttribute('data-target');
        if (dataTarget || (href && href.charAt(0) === '#')) {
            ev.preventDefault();
            ev.stopPropagation();
            var ok = scrollToSectionByRef(dataTarget || href);
            if (!ok && href && href !== '#') { window.location.href = href; }
        }
    }, true);

    // --- Run Initialization ---
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initBlocks);
    } else {
        initBlocks();
    }
})();